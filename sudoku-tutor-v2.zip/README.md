# Sudoku Tutor

Play sudoku, learn solving techniques from a skills map, and practise the skills you choose.
Live site: https://fenw1ck.github.io/Sudoku-Tutor/

## Tabs

- **Play**: standard games at Easy, Medium or Hard. Wrong digits show in red in their cell. Notes, erase, undo/redo, timer, best times.
- **Learn**: a skills map from Beginner to Advanced. Each skill has an explanation, sources, a step-by-step worked example and an exercise. The first correct digit in an exercise can only come from the skill, and it completes the puzzle.
- **Practice Skills**: tick any set of skills. The next puzzle needs every one of them, plus singles.

Difficulty is set by the hardest technique a puzzle needs:
Easy = singles (levels 1–2), Medium = pairs and locked candidates (3–4), Hard = fish and wings (5–6).

Mastery counts unassisted uses of a skill: 3 = "Getting it!", 30 = "Mastered".
Progress is saved in your browser.

## Files

| Path | What it is |
| --- | --- |
| `index.html` | Page structure |
| `css/style.css` | Styles (light and dark) |
| `js/skills.js` | The skills map: names, tiers, prerequisites, explanations, sources, difficulty bands |
| `js/engine.js` | Technique finders, logic solver, puzzle generators (no DOM, runs anywhere) |
| `js/worker.js` | Runs the generators in a Web Worker so the page never freezes |
| `js/app.js` | The interface |
| `data/bank.json` | Pre-built skill exercises (140), shuffled and relabelled each time they're used |
| `tools/build-bank.mjs` | Rebuilds `data/bank.json` |
| `tests/engine.test.mjs` | Engine tests |

## Developing

Needs Node 20 or newer for tests. No packages to install.

```
npm test                          # run the engine tests
node tools/build-bank.mjs 10 30   # rebuild the exercise bank (10 per skill, 30 s per try)
python3 -m http.server            # then open http://localhost:8000
```

The page uses JavaScript modules, so open it through a local server rather than by double-clicking `index.html`.

## Adding a technique

1. Add an entry to `SKILLS` in `js/skills.js`.
2. Write a finder in `js/engine.js` and register it in `ORDER` and `FINDERS`.
3. Run `npm test`: the soundness test checks the new finder never contradicts a solution.
4. Run `node tools/build-bank.mjs` to add exercises for it.

## Credits

Technique names follow Sudopedia, SudokuWiki and HoDoKu. Built with help from Claude (Anthropic).
