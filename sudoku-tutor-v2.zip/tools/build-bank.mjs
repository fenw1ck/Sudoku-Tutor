// Builds data/bank.json: pre-made skill-finish exercises, so Learn loads them instantly.
// Usage: node tools/build-bank.mjs [perSkill=10] [secondsPerTry=20]
import { writeFileSync } from "node:fs";
import * as E from "../js/engine.js";

const per = +(process.argv[2] || 10), secs = +(process.argv[3] || 20);
const bank = { version: 1, built: new Date().toISOString().slice(0, 10), exercises: {} };
for (const key of E.ORDER) {
  const list = [], seen = new Set();
  let tries = 0;
  while (list.length < per && tries < per * 4) {
    tries++;
    const x = E.buildExercise(key, secs * 1000);
    const id = E.encode(x.V);
    if (!x.ok || seen.has(id)) continue;
    seen.add(id);
    list.push({ v: id, s: E.encode(x.sol), empty: x.empty });
  }
  bank.exercises[key] = list;
  console.log(key.padEnd(12), `${list.length}/${per}`, `(${tries} tries)`);
}
writeFileSync(new URL("../data/bank.json", import.meta.url), JSON.stringify(bank));
console.log("wrote data/bank.json");
